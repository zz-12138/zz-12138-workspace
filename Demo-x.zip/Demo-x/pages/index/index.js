var MusicService = require('../../services/music');


//获取应用实例
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    topTabItems: ['我的', '音乐馆', '发现'],
    currentTopItem: 0,
    // swiperText: ['zz', 'aa', 'qq'],
    winHeight: 0,
    winWidth: 0,
    open: false,
    imgUrl: '/images/icon-menu.png',
    inputCurrent: '',
    indexCurrent: 1,
    searchCurrent: 1,
    userInfo: {},
    hasUserInfo: false,
    personalItem: [
      { title: "活动中心", pages: "NO MORE", pic: "/images/activity.png" },
      { title: "会员中心", pages: "SVIP", pic: "/images/VIP.png" }
    ],
    topMenu: [
      { text: "本地音乐", pic: "/images/music.png", girdUrl: '' },
      { text: "下载音乐", pic: "/images/download.png", girdUrl: '' },
      { text: "最近播放", pic: "/images/just.png", girdUrl: '' },
      { text: "我喜欢", pic: "/images/like.png", girdUrl: '../likes/likes' },
      { text: "已购音乐", pic: "/images/buy.png", girdUrl: '' },
      { text: "跑步电台", pic: "/images/run.png", girdUrl: '' }
    ],
    silder: [],
    indicatorDots: true,
    autoplay: true,
    interval: 5000,
    duration: 1000,
    songList: [
      { pic: "/images-2/9.jpg", name: "七里香", num: "10", ablumUrl: '../likes/likes' },
      { pic: "/images-2/4.jpg", name: "叶惠美", num: "11", ablumUrl: '../likes/likes' },
      { pic: "/images-2/7.jpg", name: "八度空间", num: "10", ablumUrl: '../likes/likes' },
      { pic: "/images/jay.jpg", name: "Jay", num: "10", ablumUrl: '../likes/likes' },
      { pic: "/images-2/8.jpg", name: "范特西", num: "10", ablumUrl: '../likes/likes' },
      { pic: "/images-2/3.jpg", name: "依然范特西", num: "10", ablumUrl: '../likes/likes' },
      { pic: "/images-2/10.jpg", name: "十一月的肖邦", num: "10", ablumUrl: '../likes/likes' },
      { pic: "/images-2/5.jpg", name: "寻找周杰伦", num: "2", ablumUrl: '../likes/likes' },
      { pic: "/images-2/2.jpg", name: "周杰伦的床边故事", num: "10", ablumUrl: '../likes/likes' },
      { pic: "/images-2/6.jpg", name: "我很忙", num: "10", ablumUrl: '../likes/likes' },
      { pic: "/images-2/1.jpg", name: "本周循环", num: "2", ablumUrl: '../likes/likes' },
    ]

  },

  tapPick: function () {
    if (this.data.open) {
      this.setData({
        open: false,
        imgUrl: '/images/icon-menu.png',
      })
    } else {
      this.setData({
        open: true,
        imgUrl: '/images/menu-active.png'
      })
    }
  },

  switchTab: function (e) {
    // console.log(e);
    if (this.data.currentTopItem === e.currentTarget.dataset.idx) {
      return false;
    } else {
      this.setData({
        currentTopItem: e.currentTarget.dataset.idx
      })
    }
  },

  bindChange: function (e) {
    // console.log(e);
    this.setData({
      currentTopItem: e.detail.current
    })
  },
  // 获取焦点
  bindFocus: function (event) {
    this.setData({
      indexCurrent: 0,
      searchCurrent: 1
    })
  },
  // 失去焦点
  bindBlur: function () {
    this.setData({
      indexCurrent: 1,
      searchCurrent: 0
    })
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var that = this;
    // 获取屏幕宽高
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winHeight: res.windowHeight,
          winWidth: res.windowWidth
        })
      },
    })
    //获取轮播图
    MusicService.getSwiperMusic(that.initSwiperData)

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  initSwiperData: function (data) {
    var self = this;
    if (data.code == 0) {
      self.setData({
        slider: data.data.slider,
      })
    }
  },
})
