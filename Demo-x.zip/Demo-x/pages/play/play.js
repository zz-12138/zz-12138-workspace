// pages/play/play.js

import musicList from '../../utils/data.js'
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pauseStatus: true,
    audioList: null,
    audioIndex: 0,
    itemPic: musicList[0][0],
    duration: 0,
    currentPosition: 0,
    sliderValue: 0,
  },

  // 上一曲
  bindTapPrev: function() {
    // console.log('bindTapNext')
    let length = this.data.audioList.length
    let audioIndexPrev = this.data.audioIndex
    let audioIndexNow = audioIndexPrev
    if (audioIndexPrev === 0) {
      audioIndexNow = length - 1
    } else {
      audioIndexNow = audioIndexPrev - 1
    }
    this.setData({
      audioIndex: audioIndexNow,
      sliderValue: 0,
      currentPosition: 0,
      duration: 0,
    })
    let that = this
    if (that.data.pauseStatus === false) {
      that.play()
    }
    wx.setStorageSync('audioIndex', audioIndexNow)
  },

  // 下一曲
  bindTapNext: function() {
    // console.log('bindTapNext')
    let length = this.data.audioList.length
    let audioIndexPrev = this.data.audioIndex
    let audioIndexNow = audioIndexPrev
    if (audioIndexPrev === length - 1) {
      audioIndexNow = 0
    } else {
      audioIndexNow = audioIndexPrev + 1
    }
    this.setData({
      audioIndex: audioIndexNow,
      sliderValue: 0,
      currentPosition: 0,
      duration: 0,
    })
    let that = this
    if (that.data.pauseStatus === false) {
      that.play()
    }
    wx.setStorageSync('audioIndex', audioIndexNow)
  },

  //播放
  bindTapPlay: function() {
    if (this.data.pauseStatus === true) {
      this.play()
      this.setData({
        pauseStatus: false
      })
    } else {
      wx.pauseBackgroundAudio()
      this.setData({
        pauseStatus: true
      })
    }


  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {


    // 获取当前歌曲列表
    let _listId = wx.getStorageSync("_listId")
    // console.log(_listId)

    // 获取当前歌曲
    let _songId = wx.getStorageSync('_songId')
    // console.log(_songId)

    //取歌曲列表（所有）
    let _arrId = wx.getStorageSync('_arrId')
    let _arr = wx.getStorageSync('_arr')
    if (_arrId == '') {
      this.setData({
        audioList: _arr,
        audioIndex: _songId
      })
      if (this.data.pauseStatus == true) {
        this.setData({
          pauseStatus: false
        })
      }
      this.play()
    } else {
      //取歌曲列表（专辑入口）
      let _audioList = musicList[_listId].slice(1)
      this.setData({
        audioList: _audioList,
        audioIndex: _songId
      })
      if (this.data.pauseStatus == true) {
        this.setData({
          pauseStatus: false
        })
      }
      this.play()
      console.log(this.data.audioIndex)
    }



    // 获取本地储存的audioIndex
    let audioIndexStorage = wx.getStorageSync('audioIndex')
    if (audioIndexStorage == _songId) {
      this.setData({
        audioIndex: audioIndexStorage
      })
    } else {
      this.setData({
        audioIndex: _songId
      })
    }


    // this.setData({
      //知晓云代码
      // itemPic: app.globalData.itemPic,
      // musicList: app.globalData.musicList
    // })


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {


  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },

  //播放
  play() {
    let {
      audioList,
      audioIndex
    } = this.data
    wx.playBackgroundAudio({
      dataUrl: audioList[audioIndex].src,
      title: audioList[audioIndex].name,
    })
    let that = this;
    setInterval(function() {
      that.setDuration(that)
    }, 1000)
    let _statue = {
      name: audioList[audioIndex].name,
      // statue: this.data.pauseStatus
    }
    wx.setStorageSync('_statue', _statue)
  },

  //时间换算
  setDuration(that) {
    wx.getBackgroundAudioPlayerState({
      success: function(res) {
        // console.log(res)
        let {
          status,
          duration,
          currentPosition
        } = res
        if (status === 1) {
          that.setData({
            currentPosition: that.stotime(currentPosition),
            duration: that.stotime(duration),
            sliderValue: Math.floor(currentPosition * 100 / duration),
          })
        }
        if (that.data.sliderValue == Math.floor(duration * 100 / duration)) {
          that.next();
          // console.log('a')
        }
      }
    })
  },
  next() {
    //歌曲结束自动下一曲
    let length = this.data.audioList.length
    let audioIndexPrev = this.data.audioIndex
    let audioIndexNow = audioIndexPrev
    if (audioIndexPrev === length - 1) {
      audioIndexNow = 0
    } else {
      audioIndexNow = audioIndexPrev + 1
    }
    this.setData({
      audioIndex: audioIndexNow,
      sliderValue: 0,
      currentPosition: 0,
      duration: 0,
    })
    let that = this
    if (that.data.pauseStatus === false) {
      that.play()
    }
  },
  //进度条时间换算
  stotime: function(s) {
    let t = '';
    if (s > -1) {
      let min = Math.floor(s / 60) % 60;
      let sec = s % 60;
      if (min < 10) {
        t += "0";
      }
      t += min + ":";
      if (sec < 10) {
        t += "0";
      }
      t += sec;
    }
    return t;
  }
})