// pages/likes/likes.js

import musicList from '../../utils/data.js'
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    listItem: ['单曲', '专辑', '歌单', '视频'],
    currentItem: 0,
    winHeight: 0,
    winWidth: 0,
    audioList: null,
    listIndex: 0,
    songList: [
      { pic: "/images-2/9.jpg", name: "七里香", num: "10", ablumUrl: '../likes/likes' },
      { pic: "/images-2/4.jpg", name: "叶惠美", num: "11", ablumUrl: '../likes/likes' },
      { pic: "/images-2/7.jpg", name: "八度空间", num: "10", ablumUrl: '../likes/likes' },
      { pic: "/images/jay.jpg", name: "Jay", num: "10", ablumUrl: '../likes/likes' },
      { pic: "/images-2/8.jpg", name: "范特西", num: "10", ablumUrl: '../likes/likes' },
      { pic: "/images-2/3.jpg", name: "依然范特西", num: "10", ablumUrl: '../likes/likes' },
      { pic: "/images-2/10.jpg", name: "十一月的肖邦", num: "10", ablumUrl: '../likes/likes' },
      { pic: "/images-2/5.jpg", name: "寻找周杰伦", num: "2", ablumUrl: '../likes/likes' },
      { pic: "/images-2/2.jpg", name: "周杰伦的床边故事", num: "10", ablumUrl: '../likes/likes' },
      { pic: "/images-2/6.jpg", name: "我很忙", num: "10", ablumUrl: '../likes/likes' },
    ]
    // ablumPic: musicList[0],
  },

  switchItem: function (e) {
    // console.log(e)
    if (this.data.currentItem === e.currentTarget.dataset.idx) {
      return false;
    } else {
      this.setData({
        currentItem: e.currentTarget.dataset.idx
      })
    }
  },

  bindChange: function (e) {
    // console.log(e);
    this.setData({
      currentItem: e.detail.current,
    })
  },

  //获取当前歌单
  getListId: function (e) {
    // console.log(e.target.dataset.id)
    wx.setStorageSync('_listId', e.target.dataset.id)
    
  },

  //选择歌曲
  getSongId: function(e){
    // console.log(e.target.dataset.id)
    wx.setStorageSync('_songId', e.target.dataset.id)
    
    if(this._id == undefined){
      wx.setStorageSync("_arrId", this._id)
      wx.setStorageSync("_arr", this.data.audioList)    
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _id = options.id
    var that = this;
    // console.log(options.id)

    if (_id == undefined) {

      //将数组过滤
      let _musicList = []
      for (var x = 0; x < musicList.length; x++) {
        _musicList[x] = musicList[x].slice(1)
      }

      //取所有歌曲列表
      let _audioListAll = []

      //将二维数组合并一维
      _audioListAll = _audioListAll.concat.apply(_audioListAll, _musicList)

      // console.log(_audioListAll)
      that.setData({
        audioList: _audioListAll
      })
    } else {
      //取歌曲列表
      let _audioList = musicList[_id].slice(1)
      // console.log(_audioList)
      that.setData({
        audioList: _audioList
      })
    }

    // 获取屏幕宽高
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winHeight: res.windowHeight,
          winWidth: res.windowWidth
        })
      },
    })

    //获取本地储存的audioIndex
    let audioIndexStorage = wx.getStorageSync('audioIndex')
    if (audioIndexStorage) {
      that.setData({
        audioIndex: audioIndexStorage
      })
    }

    that.setData({
      // musicList: app.globalData.musicList,
      // itemPic: app.globalData.itemPic,
      //知晓云代码
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})