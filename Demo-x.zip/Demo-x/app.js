//app.js
App({
  onLaunch: function() {

    //知晓云代码
    //wx.BaaS = requirePlugin('sdkPlugin')
    //让插件帮助完成登录、支付等功能
    // wx.BaaS.wxExtend(wx.login,
      // wx.getUserInfo,
      // wx.requestPayment)
    // require('/sdk-wechat.2.0.5-a.js')
    // wx.BaaS.init('')

    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })

    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              // 可以将 res 发送给后台解码出 unionId
              this.globalData.userInfo = res.userInfo

              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })

    //知晓云代码
    // let MyFileCategory = new wx.BaaS.FileCategory()
    // MyFileCategory.getFileList('5c9a3292c1be531f50ff4298z').then(res => {
    //   var _listname = []
    //   for(var i = 0;i < res.data.objects.length; i++){
    //     if(i > 0){
    //       _listname[i] = res.data.objects[i].name
    //     }
    //   }
    //   console.log(_listname)
    //   let _musicList = res.data.objects.slice(1);
    //   console.log(res)
    //     this.globalData.musicList = _musicList;
    //     this.globalData.itemPic = res.data.objects[0].path
    // }, err => {
    //   console.log(err)
    // })
  },

  globalData: {
    userInfo: null,
    musicList:[],
    itemPic: ''
  }

})