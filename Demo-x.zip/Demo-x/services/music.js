function getSwiperMusic(callback){
  wx.request({
    url: 'https://c.y.qq.com/musichall/fcgi-bin/fcg_yqqhomepagerecommend.fcg',
    header:{
      'content-type':'application/json'
    },
    success: function(res){
      if(res.statusCode == 200){
        callback(res.data)
        // console.log(res)
      }
    }
  })
}

module.exports = {
  getSwiperMusic: getSwiperMusic
}