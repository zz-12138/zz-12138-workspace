// components/ui-musicplay.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    
    
  },

  //组件初始化
  created: function () {
   
  },

  /**
   * 组件的初始数据
   */
  data: {
    audiostatue: true,
    songName: ''
  },

  /**
   * 组件的方法列表
   */
  methods: {
    picSwitch: function(){
      let _statue = wx.getStorageSync('_statue')
      console.log(_statue)
      this.setData({
        songName: _statue.name,
        // audiostatue: _statue.statue
      })
    },

    picClick: function(){
      if(this.data.audiostatue == true){
        this.setData({
          audiostatue: false
        })
      }else{
        this.setData({
          audiostatue: true
        })
      }
    }
  }
})
